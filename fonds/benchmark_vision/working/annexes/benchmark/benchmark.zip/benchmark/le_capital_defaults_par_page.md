# Défauts simulés par page

- **Page 1** — **Page témoin relativement propre** : Légère ombre de reliure/gouttière à gauche, papier jauni, petits points de foxing. Défaut léger servant de base de comparaison.
- **Page 2** — **Taches et auréoles** : Foxing marqué et taches d’humidité surtout en marge droite et en haut à droite.
- **Page 3** — **Faible contraste / encre pâlie** : Texte plus gris, impression délavée, rendu moins contrasté sur toute la page.
- **Page 4** — **Flou de scan / mise au point imparfaite** : Léger flou global, netteté réduite sur l’ensemble de la page.
- **Page 5** — **Page inclinée / scan de travers** : Légère rotation de la page, bords plus sombres comme sur un scan mal aligné.
- **Page 6** — **Page ondulée / déformation** : Surface gondolée avec ondulations visibles et petite déformation vers le bas de page.
- **Page 7** — **Transparence du verso** : Bleed-through : texte du verso visible en transparence derrière le texte principal.
- **Page 8** — **Pli / froissement + éclairage inégal** : Grand pli/crease traversant la page, ombre plus forte à gauche, luminosité non uniforme.
- **Page 9** — **Page tachetée / parasites** : Nombreuses petites taches, points sombres et salissures réparties sur la page.
- **Page 10** — **Marge interne sombre / cadrage serré** : Ombre de reliure plus marquée à droite, léger assombrissement périphérique et cadrage un peu serré.
